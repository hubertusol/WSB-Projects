import os
import pandas as pd
import matplotlib.pyplot as plt

current_folder = os.getcwd()
file_path = os.path.join(current_folder, 'match_results.txt')

with open(file_path, 'r') as f :
    results = f.readlines()


def split_strings_in_iterable(iterable : list, split_char : str) -> list :
    """ 
    Splits strings in an iterable by a given character
    and returns a list of lists.
    
    Parameters
    ----------
    iterable : list. List of strings.
    split_char : str. Character to split by.

    Returns
    -------
    list.

    Example
    -------
    split_strings_in_iterable( [ 'Southern Dynamo:Northern Rangers,3-0\n', 'FC Stars:Southern Galaxy,4-0\n' ], ',' )

        [ [ 'Southern Dynamo:Northern Rangers', '3-0\n' ], [ 'FC Stars:Southern Galaxy', '4-0\n' ] ]

    """
    return [i.split(split_char) for i in iterable]



def calc_outcome(homescore : int, away_score : int) -> str :
    """
    Takes the number of goals scored by home and
    away teams and based on that calculates
    the outcome 'H' (home win) / 'D' (draw) / 'A' (away win).

    Parameters
    ----------
    homescore : int.
    away_score : int.
    
    Returns
    -------
    str.
    
    Examples
    -------
    calc_outcome(2, 1)
        
        'H'
    
    calc_outcome(1, 2)
        
        'A'
    
    calc_outcome(1, 1)
        
        'D'
    
    calc_outcome(3, 4)
        
        'A'
    """
    # to determine if the home team scored
    # more goals and therefore won
    if homescore > away_score :
        return 'H'
    # to check whether away team scored more goals
    # which would make them winners
    elif homescore < away_score :
        return 'A'
    # to find out if both teams
    # scored the same number of goals
    # which would indicate a draw
    elif homescore == away_score :
        return 'D'


results_teams_scores_separate = split_strings_in_iterable(results, ',')

def get_given_elem_of_each_iterab_in_nested_iterab(iterable : list,\
                                                   idx : int = - 1) -> list :
    """
    Returns the last element of each list in a nested list.

    Parameters
    ----------
    iterable : list. List of lists.

    Returns
    -------
    list. Flat list of the last elements of each list in the nested list.

    Example
    -------
    get_last_elem_of_each_iterab_in_nested_iterab( [ [ 'Southern Dynamo:Northern Rangers', '3-0\n' ], [ 'FC Stars:Southern Galaxy', '4-0\n' ] ] )

        [ '3-0\n', '4-0\n' ]
    """

    return [i[idx] for i in iterable]

scores_only = get_given_elem_of_each_iterab_in_nested_iterab(results_teams_scores_separate)
scores_no_whitespace = [s.strip() for s in scores_only]

home_scores = [int(s.split('-')[0]) for s in scores_no_whitespace]
away_scores = [int(s.split('-')[1]) for s in scores_no_whitespace]

game_outcomes = []

for h, a in zip(home_scores, away_scores) :
    game_outcomes.append( calc_outcome( h, a ) )

pd.Series(game_outcomes).value_counts().plot.bar()
plt.title('Distribution of football games outcomes')
plt.xlabel('Outcome', labelpad = 10)
plt.ylabel('Count')
plt.show()


