import os
import pandas as pd
import matplotlib.pyplot as plt

current_folder = os.getcwd()
file_path = os.path.join(current_folder, 'match_results.txt')


class FootballData() :

    """
    A class used to represent football data from a txt file.
    
    Attributes
    ----------
    data : list. List of strings.
    teams_and_scores : list. List of lists.
    scores : list. List of strings.
    
    Static Methods
    -------
    load_data(file_path : str) -> list
    split_strings_in_iterable(iterable : list, split_char : str) -> list
    get_given_elem_of_each_iterab_in_nested_iterab(iterable : list, idx : int = - 1) -> list
    """

    # 1. tutaj wklej kod odpowiadajacy za
    # wczytanie danych z pliku i przeksztalc
    # go na metode/funkcje/metode statyczna

    # 2. tutaj wklej kod funkcji ktora rozbija stringi (lancuchy)
    # w liscie i zamien ja na metode/metode statyczna

    
    # 3. tutaj wklej kod funkcji ktora z kazdej listy w
    # liscie list (nested iterab) pobiera okreslony element i 
    # zwraca plaska liste, a nastepnie zamien ja na metode/metode statyczna

        
    def __init__(self, file_path) :
        self.data = FootballData.load_data(file_path)
        self.teams_and_scores = FootballData\
                                .split_strings_in_iterable(self.data,\
                                                           split_char = ',')
        self.scores = FootballData\
                      .get_given_elem_of_each_iterab_in_nested_iterab(\
                          self.teams_and_scores)



class FootballDataPreprocessing(FootballData) :

    """
    A class describing processing of football scores data.

    Attributes
    ----------
    file_path : str.
    data : list. List of strings.
    teams_and_scores : list. List of lists.
    scores : list. List of strings.
    scores_no_whitespace : list. List of strings.

    Methods
    -------
    extract_scores(which_side : str = 'H') -> list 
    """

    def __init__(self, file_path) :
        super().__init__(file_path)
        self.scores_no_whitespace = [s.strip() for s in self.scores]

    def extract_scores(self, which_side = 'H') :

        idx = 0

        if which_side == 'A' :
            idx = 1

        scores = [int(s.split('-')[idx]) for s in\
                       self.scores_no_whitespace]

        return scores

        

class FootballDataAnalytics(FootballDataPreprocessing) :

    """ 
    A class for analyzing football scores data.
    
    Attributes
    ----------
    file_path : str.
    data : list. List of strings.
    teams_and_scores : list. List of lists.
    scores : list. List of strings.
    scores_no_whitespace : list. List of strings.
    home_scores : list. List of integers.
    away_scores : list. List of integers.
    outcomes : list. List of strings.
    
    Methods
    -------
    get_counts_of_outcomes() -> pd.Series
    plot_counts_of_outcomes()
    
    Static Methods
    -------
    calc_outcome(homescore : int, away_score : int) -> str"""

    # 4. tutaj wklej kod funkcji ktora na podstawie ilosci
    # goli strzelonych przez gospodarzy i druzyne przyjezdna
    # mowi kto wygral mecz
    # a nastepnie zamien ja na metode/metode statyczna

    def __init__(self, file_path) :
        super().__init__(file_path)
        self.home_scores = self.extract_scores(which_side = 'H')
        # 5. tutaj oblicz wyniki druzyn przyjezdnych 
        self.outcomes = [ FootballDataAnalytics\
                          .odpowiednia_metoda( h, a ) for h, a in zip(\  
            self.home_scores, self.away_scores)]
# 7. 2 linijki wyzej zamien odpowiednia_metoda na nazwe metody, ktora
# pozwala ustalic wynik meczu
    

    def get_counts_of_outcomes(self) :
        # 8. dostosuj ponizsza linijke kodu wstawiajac cos zamiast '???'
        # ta metoda liczy czestosc poszczegolnych wynikow meczow
        return pd.Series('???').value_counts()

    def plot_counts_of_outcomes(self) :

        self.get_counts_of_outcomes().plot.bar()
        plt.title('Distribution of football games outcomes')
        plt.xlabel('Outcome', labelpad = 10)
        plt.ylabel('Count')
        plt.show()
        
        

print(FootballDataAnalytics(file_path).plot_counts_of_outcomes())
