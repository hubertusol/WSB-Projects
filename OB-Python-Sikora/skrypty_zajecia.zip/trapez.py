class Trapezoid() :
    
    def __init__(self, a, b, c, d, h) :
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.h = h

    def get_trapezoid_info(self) :

        print( "Jest to trapez o podstawach {} i {} oraz bokach {} i {} i wysokości {}."\
              .format( self.a, self.b, self.c, self.d, self.h ) )

    
    def calc_perimeter(self) :
        return sum( [ self.a, self.b, self.c, self.d ] )
    
    def calc_area(self) :
        return ( ( self.a + self.b ) * self.h ) / 2



class Trapezoid() :

    """ 
    A class used to represent a trapezoid.
    It describes how to calculate the area and perimeter of a trapezoid.

    Attributes
    ----------
    a : float or int
        The length of the first parallel side of the trapezoid.
    b : float or int
        The length of the second parallel side of the trapezoid.
    c : float or int
        The length of the first non-parallel side of the trapezoid.
    d : float or int
        The length of the second non-parallel side of the trapezoid.
    
    h : float or int
        The height of the trapezoid.

    Methods
    -------
    calc_perimeter()
        Returns the perimeter of the trapezoid.
    
    calc_area()
        Returns the area of the trapezoid.
    
    Examples
    --------
    >>> trapez = Trapezoid(3, 4, 5, 6, 7)
    >>> trapez.calc_perimeter()
            
            18
    
    >>> trapez.calc_area()

            24.5
    >>> trapez.get_trapezoid_info()

            Jest to trapez o podstawach 3 i 4 oraz bokach 5 i 6 i wysokości 7.
    """
    
    def __init__(self, a, b, c, d, h) :
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.h = h

    def get_trapezoid_info(self) :

        """
        Prints the information about the trapezoid, 
        meaning the lengths of its sides and its height.
        """

        print( "Jest to trapez o podstawach {} i {} oraz bokach {} i {} i wysokości {}."\
              .format( self.a, self.b, self.c, self.d, self.h ) )

    
    def calc_perimeter(self) :
        """ 
        Returns the perimeter of the trapezoid.
        
        Returns
        -------
        float or int
            The perimeter of the trapezoid.
        """
        return sum( [ self.a, self.b, self.c, self.d ] )
    
    def calc_area(self) :
        """ 
        Returns the area of the trapezoid.

        Returns
        -------
        float or int
            The area of the trapezoid.
        """
        return ( ( self.a + self.b ) * self.h ) / 2


trapez = Trapezoid(3, 4, 5, 6, 7)
print(trapez.calc_area())

